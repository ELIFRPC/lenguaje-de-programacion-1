#include <iostream>
using namespace std;

int main() {
	int edad;
	cout << "ingrese un valor ";
	cin >> edad;
	if (edad > 17)
	{
		cout<<"ES MAYOR DE EDAD";
	}
	else{
		cout << "ES MENOR DE EDAD";
	}

	return 0;
	
}
